#include "lexer.cpp"


int main() {
	printf("token\t\tlexeme\n");
	printf("-----\t\t------\n");
	Lexer lex;
	lex.checkFile();

}
