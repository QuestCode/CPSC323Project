//
//  CharacterClass.cpp
//  Compiler_Project
//
//  Created by Devontae Reid on 3/21/18.
//  Copyright © 2018 Devontae Reid. All rights reserved.
//

enum Character {
    /* Identifiers Token codes */
    LETTER,DIGIT,DOLLAR_SIGN,PERIOD,COMMENT,UNKNOWN,E_O_F
};
